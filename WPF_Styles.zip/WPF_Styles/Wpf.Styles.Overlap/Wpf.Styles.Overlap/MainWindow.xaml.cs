﻿using System.Windows;

namespace Wpf.Styles.Overlap
{
    internal sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}