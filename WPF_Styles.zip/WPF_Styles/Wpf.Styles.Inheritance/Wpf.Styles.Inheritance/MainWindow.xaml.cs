﻿using System.Windows;

namespace Wpf.Styles.Inheritance
{
    internal sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}