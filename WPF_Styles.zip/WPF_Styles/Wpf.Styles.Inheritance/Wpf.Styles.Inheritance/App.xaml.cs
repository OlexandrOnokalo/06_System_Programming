﻿using System.Windows;

namespace Wpf.Styles.Inheritance
{
    internal sealed partial class App : Application
    {
    }
}