﻿using System.Windows;

namespace Wpf.Styles
{
    internal sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}