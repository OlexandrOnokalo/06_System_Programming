﻿using System.Windows;

namespace Wpf.Styles
{
    internal sealed partial class App : Application
    {
    }
}