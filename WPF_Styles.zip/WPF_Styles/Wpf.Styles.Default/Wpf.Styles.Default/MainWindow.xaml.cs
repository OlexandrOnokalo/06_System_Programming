﻿using System.Windows;
using System.Windows.Media;

namespace Wpf.Styles.Default
{
    internal sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}