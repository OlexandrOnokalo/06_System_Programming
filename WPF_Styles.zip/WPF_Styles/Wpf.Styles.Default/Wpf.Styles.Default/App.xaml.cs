﻿using System.Windows;

namespace Wpf.Styles.Default
{
    internal sealed partial class App : Application
    {
    }
}